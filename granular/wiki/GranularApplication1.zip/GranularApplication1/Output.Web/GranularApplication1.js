﻿(function() {
	'use strict';
	var $asm = {};
	global.GranularApplication1 = global.GranularApplication1 || {};
	ss.initAssembly($asm, 'GranularApplication1', { 'GranularApplication1.MainWindow.xaml': '77u/PFdpbmRvdyB4OkNsYXNzPSJHcmFudWxhckFwcGxpY2F0aW9uMS5NYWluV2luZG93Ig0KICAgICAgICB4bWxucz0iaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93aW5meC8yMDA2L3hhbWwvcHJlc2VudGF0aW9uIg0KICAgICAgICB4bWxuczp4PSJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dpbmZ4LzIwMDYveGFtbCINCiAgICAgICAgVGl0bGU9Ik1haW5XaW5kb3ciPg0KICAgIDxHcmlkPg0KICAgICAgICA8QnV0dG9uIFdpZHRoPSIxMDAiIEhlaWdodD0iMzAiPkhlbGxvPC9CdXR0b24+DQogICAgPC9HcmlkPg0KPC9XaW5kb3c+DQo=', 'GranularApplication1.App.xaml': '77u/PEFwcGxpY2F0aW9uIHg6Q2xhc3M9IkdyYW51bGFyQXBwbGljYXRpb24xLkFwcCINCiAgICAgICAgICAgICAgIHhtbG5zPSJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dpbmZ4LzIwMDYveGFtbC9wcmVzZW50YXRpb24iDQogICAgICAgICAgICAgICB4bWxuczp4PSJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dpbmZ4LzIwMDYveGFtbCINCiAgICAgICAgICAgICAgIFN0YXJ0dXBVcmk9Ii9HcmFudWxhckFwcGxpY2F0aW9uMTtjb21wb25lbnQvTWFpbldpbmRvdy54YW1sIj4NCiAgICA8QXBwbGljYXRpb24uUmVzb3VyY2VzPg0KICAgIDwvQXBwbGljYXRpb24uUmVzb3VyY2VzPg0KPC9BcHBsaWNhdGlvbj4=' });
	////////////////////////////////////////////////////////////////////////////////
	// GranularApplication1.App
	var $GranularApplication1_App = function() {
		System.Windows.Application.call(this);
	};
	$GranularApplication1_App.__typeName = 'GranularApplication1.App';
	$GranularApplication1_App.Main = function() {
		System.Windows.ApplicationHost.get_Current().Run(function() {
			var application = new $GranularApplication1_App();
			application.$InitializeComponent();
			application.Run();
		});
	};
	global.GranularApplication1.App = $GranularApplication1_App;
	////////////////////////////////////////////////////////////////////////////////
	// GranularApplication1.MainWindow
	var $GranularApplication1_MainWindow = function() {
		System.Windows.Window.call(this);
		this.$InitializeComponent();
	};
	$GranularApplication1_MainWindow.__typeName = 'GranularApplication1.MainWindow';
	global.GranularApplication1.MainWindow = $GranularApplication1_MainWindow;
	ss.initClass($GranularApplication1_App, $asm, {
		$InitializeComponent: function() {
			System.Windows.Application.LoadComponent$1(this, '/GranularApplication1;component/App.xaml');
		}
	}, System.Windows.Application, [System.Windows.IResourceContainer]);
	ss.initClass($GranularApplication1_MainWindow, $asm, {
		$InitializeComponent: function() {
			System.Windows.Application.LoadComponent$1(this, '/GranularApplication1;component/MainWindow.xaml');
		}
	}, System.Windows.Window, [System.Windows.Media.Animation.IAnimatable, System.Windows.IInputElement, System.Windows.IResourceContainer, System.Windows.Controls.IItemContainer, System.Windows.Controls.IPopupLayerHost, System.Windows.Controls.IAdornerLayerHost]);
	ss.setMetadata($GranularApplication1_App, { members: [{ name: '.ctor', type: 1, params: [] }, { attr: [new System.STAThreadAttribute()], name: 'Main', isStatic: true, type: 8, sname: 'Main', returnType: Object, params: [] }] });
	ss.setMetadata($GranularApplication1_MainWindow, { members: [{ name: '.ctor', type: 1, params: [] }] });
	$asm.attr = [new System.Windows.ApplicationHostAttribute(Granular.Host.WebApplicationHost)];
	$GranularApplication1_App.Main();
})();
