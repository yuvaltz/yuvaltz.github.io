﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows;

namespace GranularTestApplication
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
